alert("Press OK to Pass Me! =)")
/*
SDI 1207
Week 4 Deliverable: Project 4
Randall Mathews
*/



var theLibrary = function(){
	
	// Does a string follow a 123-456-7890 pattern like a phone number?
	
	var phoneNumber = function (phoneNum) { //Function and argument
    var checkPhone = phoneNum;
    var number = /^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$/; //Regular Expession test
        if (number.test (checkPhone)) { //Conditonal that varifies the RegEx results, T or F
            return true;
		}else{
			return false;
        };
	};
	
	
	// Does a string follow an aaa@bbb.ccc pattern like an email address?
	
	var email = function (address) { //Function and argument
	var checkEmail = address;
	var email = /^([A-Za-z0-9_\-\.]){1,}\@([A-Za-z0-9_\-\.]){1,}\.([A-Za-z]{2,4})$/; //Regular Expession test
		if (email.test(checkEmail)) { //Conditonal that varifies the RegEx results, T or F
			return true;
		} else {
			return false;
		};
	};

	//Format a number to use a specific number of decimal places, as for money: 2.1 ? 2.10

	var numberFormat = function (numberDecimal) { //Function and argument
    var decimal = numberDecimal;
    	return(decimal.toFixed(2)); //method used to format a number and use a specific number of trailing decimals
	
	};
	
	// Find the number of hours or days difference between two dates. Counting down Mayan calender.

	var day = function (yyyy, mm, dd) { //Function and argument
	var today = new Date(); //varible setting new date which is current date
	var theFuture = new Date (yyyy, mm-1, dd); //variable setting new date argument
	var minutes = (theFuture - today)/60000; //varaible that is taking the result and dividing it by milliseconds in a minute
	var hours = minutes / 60; //variable that is taking the above result and converting it into minutes
	var days = Math.floor(hours/24); //this method rounds down the result
		return days;
	
	};
	
	//Is the string a URL? (Does it start with http: or https:?)
	
	var validateUrl = function (url) { //Function and argument
    var urlPattern = /(ftp|http|https):\/\/(\w+:{0,1}\w*@)?(\S+)(:[0-9]+)?(\/|\/([\w#!:.?+=&%@!\-\/]))?/; //RegEx test 
		if(urlPattern.test(url)) { //Conditonal that varifies the RegEx results, T or F
            return true;
        }else{
			return false;
        };

    };	
	
	// Title-case a string (split into words, then uppercase the first letter of each word.)

	var changeCase = function (makeUpper) { //Function and argument 
    String.prototype.toProperCase = function () { // This method capitalizes the first letter of every word in a string
		return this.replace(/\w\S*/g, function (txt) { //Thes RegEx will search for anything in a string separated by a white space
            return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase(); //see below
        });
	};
			return(makeUpper.toProperCase());
	
	};
		// The txt.charAt(0) returns the character at that index then converts it to uppercase + This removes the extra character after conversion.

	
	return{
			
			"phoneNumber":phoneNumber,
			"email":email,
			"numberFormat":numberFormat,
			"day":day,
			"validateUrl":validateUrl,
			"changeCase":changeCase

		};
		
		
	};


