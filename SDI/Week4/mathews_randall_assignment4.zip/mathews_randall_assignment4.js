var newLib = new theLibrary();


console.log(newLib.phoneNumber("575-867-5309"));
console.log(newLib.email("stan@theman.net"));
console.log(newLib.numberFormat(34.5678));
console.log(newLib.day(2012, 12, 21));
console.log(newLib.validateUrl("ftp://www.google.com"));
console.log(newLib.validateUrl("http://www.google.com"));
console.log(newLib.validateUrl("https://www.google.com"));
console.log(newLib.validateUrl("www.google.com"));
console.log(newLib.changeCase("compute gazette magazine"));
	