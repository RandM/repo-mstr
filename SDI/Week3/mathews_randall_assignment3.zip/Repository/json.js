

var json = {
"treatment" : [
		{	
			"type": "0012",
			"name": "massage",
			"area": "back",
			"amount": "10 min"
		},
		{
			"type": "0013",
			"name": "ultrasound",
			"area": "back",
			"amount": "5 min"
		},	
		{
			"type": "0014",
			"name": "electrostimu",
			"area": "shoulder",
			"amount": "15 min"
		}
	]


};




/*
********* Moved to the main.js file **********

json.treatment.push(
		{
			"type": "0015",
			"name": "workout",
			"area": "legs",
			"amount": "20 min"  
			
		}
			
); //

*/

